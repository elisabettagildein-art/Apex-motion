APEX — GitHub Pages Website
==========================

1. Entpacke apex-motion-site.zip.
2. Öffne github.com und melde dich an.
3. Erstelle ein neues Repository, z. B. "apex-sportwagen".
4. Lade index.html (und README.txt optional) in das Hauptverzeichnis hoch.
   Auf GitHub: Add file -> Upload files -> Dateien auswählen -> Commit changes.
5. Öffne im Repository Settings -> Pages.
6. Unter "Build and deployment" bei Source "Deploy from a branch" wählen.
7. Branch "main", Ordner "/ (root)" auswählen und Save drücken.
8. Nach dem Veröffentlichen findest du die Website unter:
   https://DEIN-BENUTZERNAME.github.io/apex-sportwagen/

Die Seite ist eine einzelne statische HTML-Datei und braucht keinen Build-Schritt.
Sie ist für Desktop, Smartphone und iPad responsiv. Die Auto-Grafik ist als SVG
direkt eingebaut; die Bewegung reagiert auf Scrollen. Google Fonts benötigen
Internet. Die Website ist ein fiktives Designkonzept, keine echte Automarke.
